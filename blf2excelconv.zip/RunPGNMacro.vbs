Set args = WScript.Arguments
If args.Count = 0 Then
   MsgBox "Drag and drop an Excel or CSV file onto this script.", vbExclamation
   WScript.Quit
End If
inputPath = args(0)
Set xlApp = CreateObject("Excel.Application")
xlApp.Visible = True
' Open the macro-enabled workbook where the macro is stored
Set fso = CreateObject("Scripting.FileSystemObject")
currentDir = fso.GetParentFolderName(WScript.ScriptFullName)
Set wbMacro = xlApp.Workbooks.Open(currentDir & "\Support Files\PGNTool.xlsm")
'Set wbMacro = xlApp.Workbooks.Open("D:\AI Demo\AI Idea 1\PGNTool.xlsm") ' <-- UPDATE THIS LINE
' Open the input file (CSV or XLSX)
Set wbInput = xlApp.Workbooks.Open(inputPath)
' Set input workbook as active so the macro works on it
wbInput.Activate
' Run macro from PGNTool but let it act on active workbook
xlApp.Run "PGNTool.xlsm!SuperFast_CleanAndMapPGN"
' Optional: Save the processed file
' wbInput.Save
' Optional: Close both workbooks
' wbInput.Close SaveChanges:=True
' wbMacro.Close SaveChanges:=False
' xlApp.Quit