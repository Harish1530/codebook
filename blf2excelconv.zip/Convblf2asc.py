import os
import subprocess
import tkinter as tk
from tkinter import filedialog, messagebox
from can.io.blf import BLFReader
from can.io.asc import ASCWriter
import sys
import shutil

# --- Define files and paths ---
blf_file_path = None
asc_file_path = None
xlsx_file_path = None
vbscript_file_name = "RunPGNMacro.vbs"
macro_workbook_name = "PGNTool.xlsm"
object_list_name = "ObjectList.xlsx"


# --- Function to get the file path for PyInstaller ---
def get_resource_path(relative_path):
    try:
        # PyInstaller creates a temporary folder and stores the path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)


# --- Function to open file dialog ---
def select_input_blf_file():
    root = tk.Tk()
    root.withdraw()
    file_path = filedialog.askopenfilename(
        title="Select a BLF file", filetypes=[("BLF files", "*.blf")]
    )
    root.destroy()
    return file_path


def main():
    global blf_file_path, asc_file_path, xlsx_file_path

    # Step 0: Select the input file
    blf_file_path = select_input_blf_file()
    if not blf_file_path:
        print("No BLF file selected. Exiting.")
        return

    output_dir = os.path.dirname(blf_file_path)
    base_filename = os.path.splitext(os.path.basename(blf_file_path))[0]
    asc_file_path = os.path.join(output_dir, f"{base_filename}_output.asc")
    xlsx_file_path = os.path.join(output_dir, f"{base_filename}_output.xlsx")

    try:
        # Step 1: Convert .blf to .asc
        with open(blf_file_path, 'rb') as f_in:
            blf_reader = BLFReader(f_in)
            with open(asc_file_path, 'w') as f_out:
                asc_writer = ASCWriter(f_out)
                for msg in blf_reader:
                    asc_writer.on_message_received(msg)
                asc_writer.stop()
        print(f"Successfully converted '{blf_file_path}' to '{asc_file_path}'")
    except Exception as e:
        messagebox.showerror("Error", f"An error occurred during conversion to ASC: {e}")
        return

    if os.path.exists(asc_file_path):
        # The VBScript expects an XLSX file, not an ASC file.
        # This conversion step is still necessary.
        import pandas as pd
        df = pd.read_csv(asc_file_path, delimiter='\t', header=None) # Adjust delimiter as needed
        df.to_excel(xlsx_file_path, index=False)
        os.remove(asc_file_path)
        print(f"Intermediate ASC file removed. Created initial '{xlsx_file_path}'.")

        try:
            # Replicate the required VBScript directory structure in the temporary folder
            temp_dir = get_resource_path('.')
            support_files_dir = os.path.join(temp_dir, "Support Files")
            os.makedirs(support_files_dir, exist_ok=True)
            
            # Copy the necessary files to the new directory
            shutil.copy(get_resource_path(macro_workbook_name), support_files_dir)
            shutil.copy(get_resource_path(object_list_name), support_files_dir)

            # Step 2: Run the VBScript with the created XLSX file path as an argument
            vbscript_file_path = get_resource_path(vbscript_file_name)
            if os.path.exists(vbscript_file_path):
                subprocess.run(
                    ["cscript", vbscript_file_path, os.path.abspath(xlsx_file_path)],
                    check=True,
                    text=True,
                    capture_output=True
                )
                print(f"Successfully ran VBScript '{vbscript_file_path}'.")
                
            else:
                messagebox.showerror("File Not Found", f"Error: VBScript file '{vbscript_file_name}' not found.")
                
        except subprocess.CalledProcessError as e:
            messagebox.showerror("VBScript Error", f"Error running VBScript:\n{e.stderr}")
        except FileNotFoundError:
            messagebox.showerror("VBScript Error", "VBScript interpreter (cscript.exe) not found.")
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred while running the VBScript: {e}")
    else:
        messagebox.showerror("File Not Found", f"ASC file '{asc_file_path}' was not created.")
    
    messagebox.showinfo("Process Complete", "Conversion complete!")


if __name__ == "__main__":
    main()
