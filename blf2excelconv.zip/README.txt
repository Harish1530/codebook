How to use:
Step 1: Open "Command Prompt" int the folder where the folder is and run the command "pip install -r requirements.txt"
Step 2: Run Command "py Convblf2asc.py" and select the .blf file on the file browser.
Step 3: An Excel file will be open in the background. Please Click and bring it on the active Screen. A Popup shall appear on the Excel screen.
Step 4: Press "Ctrl + S" to save the excel file.

